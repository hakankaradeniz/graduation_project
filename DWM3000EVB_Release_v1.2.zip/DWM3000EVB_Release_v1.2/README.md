# DWM3000EVB Software and API Guide Release Note

Binary, sources, and documentation structured in an appropriate folders:

- Docs 

- DW3XXX API Package v9.3 / Driver v06.00.07 

/signed
21-Jan-2022